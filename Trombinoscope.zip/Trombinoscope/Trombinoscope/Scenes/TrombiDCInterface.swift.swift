//
//  TrombiDCInterface.swift.swift
//  Trombinoscope
//
//  Created by lesly on 22.09.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import ServerWorker
import Shared
import UIKit

/// The act's dependency container.
protocol TrombiDCInterface: AnyObject {
    /// The configuration properties.
    var configuration: Configuration { get }

    /// The factory for creating new dependencies.
    var factory: TrombiFactoryInterface { get }

    /// The internal settings to persist app settings data.
    var settings: InternalSettingsInterface { get }

    /// A server worker for querying server requests.
    var serverWorker: ServerWorkerInterface { get }
}

/// The act's factory which creates new dependency objects.
protocol TrombiFactoryInterface {
    /**
     Creates and returns a new scene.

     - parameter scene: Which scene to create.
     - returns: The created scene.
     */
    func scene(_ scene: TrombiScene) -> UIViewController



}

