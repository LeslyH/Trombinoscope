// Any scene specific types.
enum DetailModel {
}
