import Shared

extension Const {
	/// Identifier names for UI scene testing.
	struct DetailTests {
		/// The scene's main view.
		static let mainView = "DetailView"
	}
}
