extension SetupModel {
	/// The scene's setup model.
	struct Detail {
		/// The closure for passing back some values to the previous scene.
		let callback: DetailCallback
	}

	typealias DetailCallback = (_ model: DetailResult) -> Void

	/// The model to pass back to the parent controller.
	struct DetailResult {
	}
}
