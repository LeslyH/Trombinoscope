import Shared

extension Const {
	/// Any constants for this scene.
	struct Detail {}
}
