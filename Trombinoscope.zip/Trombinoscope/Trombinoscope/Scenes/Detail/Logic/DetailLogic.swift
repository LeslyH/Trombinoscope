import Foundation

extension DetailModel {
	/// The dependencies for the logic to inject.
	struct LogicDependencies {
		let setupModel: SetupModel.Detail
		let presenter: DetailPresenterInterface
		let navigator: DetailNavigatorInterface
		let actDependencies: TrombiDCInterface
	}
}

/**
 The business logic for this scene.
 This class is responsible for any logic happening in the scene.
 */
final class DetailLogic {
	/// The data model holding the current scene's logic state.
	private(set) var state = DetailModel.LogicState()

	/// The injected dependencies.
	private let dependencies: DetailModel.LogicDependencies

	required init(dependencies: DetailModel.LogicDependencies) {
		self.dependencies = dependencies
	}
}

// MARK: - DetailLogicInterface

extension DetailLogic: DetailLogicInterface {
	func updateDisplay() {
		let model = DetailModel.Presenter.UpdateView()
		dependencies.presenter.updateView(model: model)
	}

    func updateParentScene() {
        let model = SetupModel.DetailResult()
        dependencies.setupModel.callback(model)
    }
}
