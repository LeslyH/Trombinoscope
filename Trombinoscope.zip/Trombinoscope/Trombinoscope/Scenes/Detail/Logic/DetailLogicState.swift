extension DetailModel {
	/// The scene's actual state.
	struct LogicState {
	}
}
