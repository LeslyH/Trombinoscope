/// Navigation for this scene.
protocol DetailNavigatorInterface: AnyObject {
}
