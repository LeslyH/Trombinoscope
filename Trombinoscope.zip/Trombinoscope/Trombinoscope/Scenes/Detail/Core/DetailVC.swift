import UIKit

/**
 The view controller which is the main module for this scene and thus creates and holds all components of it.
 */
final class DetailVC: BaseViewController {
	/// A strong reference to the interactor which binds the display to the logic.
	private var interactor: DetailInteractor?

	// A strong reference to the presenter which presents data on the view.
	private let presenter = DetailPresenter()

	// A strong reference to the navigator which is responsible for routing.
	private let navigator: DetailNavigator

	// A strong reference to the business logic.
	private let logic: DetailLogic

	required init(setupModel: SetupModel.Detail, dependencies actDependencies: TrombiDCInterface) {
		navigator = DetailNavigator(dependencies: actDependencies)
		let logicDependencies = DetailModel.LogicDependencies(
			setupModel: setupModel,
			presenter: presenter,
			navigator: navigator,
			actDependencies: actDependencies
		)
		logic = DetailLogic(dependencies: logicDependencies)
		super.init()
		navigator.viewController = self
		presenter.viewController = self
	}

	// MARK: - View

	override func loadView() {
		let sceneView = DetailView()
		view = sceneView
		presenter.view = sceneView
		interactor = DetailInteractor(view: sceneView, logic: logic)
	}

	override func viewWillAppear(_ animated: Bool) {
		super.viewWillAppear(animated)

		if isMovingToParent || isBeingPresented {
			// Request initial display data.
			logic.updateDisplay()
		}
	}

	override func viewWillDisappear(_ animated: Bool) {
		super.viewWillDisappear(animated)

		if isMovingFromParent || isBeingDismissed {
			// Scene is transitioning back to the previous.
			logic.updateParentScene()
		}
	}
}
