import UIKit

/// The interface for presenting something in the view.
protocol DetailPresenterInterface: AnyObject {
	/**
	 Updates the whole view according to the given state.

	 - parameter model: The new state.
	 */
	func updateView(model: DetailModel.Presenter.UpdateView)
}

extension DetailModel {
	/// The models send to the presenter.
	enum Presenter {
		struct UpdateView {
		}
	}
}
