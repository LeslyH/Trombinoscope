//
//  TrombiDC.swift
//  Trombinoscope
//
//  Created by lesly on 22.09.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import ServerWorker
import Shared
import UIKit
var imageCache = NSCache<NSString, UIImage>()
class TrombiDC: TrombiDCInterface {
    lazy var factory: TrombiFactoryInterface = {
        Act1Factory(dependencies: self)
    }()

    let configuration: Configuration
    let settings: InternalSettingsInterface
    let serverWorker: ServerWorkerInterface

    init(
        configuration: Configuration,
        settings: InternalSettingsInterface,
        serverWorker: ServerWorkerInterface
    ) {
        self.configuration = configuration
        self.settings = settings
        self.serverWorker = serverWorker
    }
}

class Act1Factory: TrombiFactoryInterface {
    /// The reference to the dependency container, but unowned because the container owns the factory.
    unowned let dependencies: TrombiDCInterface

    init(dependencies: TrombiDCInterface) {
        self.dependencies = dependencies
    }

    func scene(_ scene: TrombiScene) -> UIViewController {
        switch scene {
        case let .list(setupModel):
            return ListVC(setupModel: setupModel, dependencies: dependencies)
        case let .detail(setupModel):
            return DetailVC(setupModel: setupModel, dependencies: dependencies)
        }
    }


}
