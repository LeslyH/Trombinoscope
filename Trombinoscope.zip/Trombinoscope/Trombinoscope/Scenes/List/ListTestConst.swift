import Shared

extension Const {
	/// Identifier names for UI scene testing.
	struct ListTests {
		/// The scene's main view.
		static let mainView = "ListView"
	}
}
