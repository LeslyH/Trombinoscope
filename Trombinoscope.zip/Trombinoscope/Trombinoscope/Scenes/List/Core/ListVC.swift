import UIKit

/**
 The view controller which is the main module for this scene and thus creates and holds all components of it.
 */
final class ListVC: BaseViewController {
	/// A strong reference to the interactor which binds the display to the logic.
	private var interactor: ListInteractor?

	// A strong reference to the presenter which presents data on the view.
	private let presenter = ListPresenter()

	// A strong reference to the navigator which is responsible for routing.
	private let navigator: ListNavigator

	// A strong reference to the business logic.
	private let logic: ListLogic
    
    // A strong reference to the collectionView Controller
    private var collectionController: ListCollectionController?

	required init(setupModel: SetupModel.List, dependencies actDependencies: TrombiDCInterface) {
		navigator = ListNavigator(dependencies: actDependencies)
		let logicDependencies = ListModel.LogicDependencies(
			setupModel: setupModel,
			presenter: presenter,
			navigator: navigator,
			actDependencies: actDependencies
		)
		logic = ListLogic(dependencies: logicDependencies)
		super.init()
		navigator.viewController = self
		presenter.viewController = self
	}

	// MARK: - View

	override func loadView() {
		let sceneView = ListView()
		view = sceneView
		presenter.view = sceneView
		interactor = ListInteractor(view: sceneView, logic: logic)
        
        
        collectionController = ListCollectionController(sceneView: sceneView, collectionView: sceneView.collectionView, logic: logic)
        presenter.collectionController = collectionController
    
	}
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }

	override func viewWillAppear(_ animated: Bool) {
		super.viewWillAppear(animated)
          logic.getDeveloperList()
		if isMovingToParent || isBeingPresented {
			// Request initial display data.
			logic.updateDisplay()

		}
	}

	override func viewWillDisappear(_ animated: Bool) {
		super.viewWillDisappear(animated)

		if isMovingFromParent || isBeingDismissed {
			// Scene is transitioning back to the previous.
			logic.updateParentScene()
		}
	}
}
