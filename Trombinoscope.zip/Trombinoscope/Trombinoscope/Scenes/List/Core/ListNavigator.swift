import UIKit

/// The navigator for this scene.
final class ListNavigator {
	/// A weak reference to the scene's view controller this router performs transitions on.
	/// Has to be assigned via property injection after initialization.
	weak var viewController: UIViewController?

	/// A reference to the dependency container.
	private let dependencies: TrombiDCInterface

	init(dependencies: TrombiDCInterface) {
		self.dependencies = dependencies
	}
}

// MARK: - ListNavigatorInterface

extension ListNavigator: ListNavigatorInterface {
}
