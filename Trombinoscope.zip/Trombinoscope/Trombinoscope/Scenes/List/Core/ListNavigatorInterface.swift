/// Navigation for this scene.
protocol ListNavigatorInterface: AnyObject {
}
