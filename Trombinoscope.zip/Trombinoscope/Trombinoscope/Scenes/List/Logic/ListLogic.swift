import Foundation
import ServerWorker
extension ListModel {
	/// The dependencies for the logic to inject.
	struct LogicDependencies {
		let setupModel: SetupModel.List
		let presenter: ListPresenterInterface
		let navigator: ListNavigatorInterface
		let actDependencies: TrombiDCInterface
	}
}

/**
 The business logic for this scene.
 This class is responsible for any logic happening in the scene.
 */
final class ListLogic {
	/// The data model holding the current scene's logic state.
	private(set) var state = ListModel.LogicState()

	/// The injected dependencies.
	private let dependencies: ListModel.LogicDependencies

	required init(dependencies: ListModel.LogicDependencies) {
		self.dependencies = dependencies
	}
}

// MARK: - ListLogicInterface

extension ListLogic: ListLogicInterface {
	func updateDisplay() {
		let model = ListModel.Presenter.UpdateView()
		dependencies.presenter.updateView(model: model)
	}

    func updateParentScene() {
        let model = SetupModel.ListResult()
      //  dependencies.setupModel.callback(model)
    }
    
    func getDeveloperList(){
         
         
         let request = Request.getDeveloper.Text("")
              dependencies.actDependencies.serverWorker.send(request) { [weak self] result in
                 
                  guard let strongSelf = self else { return }
                 
                 
                  switch result {
                  case let .failure(error):
                      print(error)
                      strongSelf.dependencies.presenter.serverError(error)
                 
                  case let .success(result):
                      //strongSelf.state.lastTrails = result.trails
                    //  print(result)
                 
                     DispatchQueue.main.async {
                        strongSelf.dependencies.presenter.developersList(developers: result)
                    }
                  }
              }
         
     }
}
