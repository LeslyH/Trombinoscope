extension ListModel {
	/// The scene's actual state.
	struct LogicState {
	}
}
