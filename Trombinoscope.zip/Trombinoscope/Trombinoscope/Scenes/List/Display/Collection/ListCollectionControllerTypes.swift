//
//  ListCollectionControllerTypes.swift
//  Trombinoscope
//
//  Created by lesly on 22.09.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import Foundation
/// A default cell.

    /// The collection's cell representations.
    enum ListCollectionData {
        /// A default cell.
        case defaultCell(_ model: ListDefaultCellModel)
    }
