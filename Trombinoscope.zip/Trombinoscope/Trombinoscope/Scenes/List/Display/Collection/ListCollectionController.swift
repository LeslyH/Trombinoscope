//
//  ListCollectionController.swift
//  Trombinoscope
//
//  Created by lesly on 22.09.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import Foundation
import Shared
import UIKit

///TODO: Manage optionnal values
class ListCollectionController: NSObject {
    
    /// The table view this controller manages.
    private unowned let collectionView: UICollectionView
    private unowned let sceneView: UIView
    
    /// A reference to the logic to inform about user actions in the table.
    private unowned let logic: ListLogicInterface
    
    /**
     Initializes the controller via dependency injection.

     - parameter collectionView: The collection view this controller manages. Will be referenced as unowned.
     - parameter logic: The logic to inform about specific actions. Will be referenced as unowned.
     */
    init(sceneView: UIView,collectionView: UICollectionView, logic: ListLogicInterface) {
        self.collectionView = collectionView
        self.logic = logic
        self.sceneView = sceneView
        super.init()

        // Set up table view.
        collectionView.delegate = self
        collectionView.dataSource = self

        // Register cells.
        collectionView.register(ListDefaultCell.self, forCellWithReuseIdentifier:Const.List.collectionCellID)
       

        
    }
    // MARK: - Table content

    /// The original model of which the tableData is created.
    private var currentModel: ListCollectionModel.DataModel?

    /// The data representation for the collection view consisting of the cell types and their models.
    private var collectionData = [ListCollectionData]()
    /**
    Creates the data for the table view and updates the `currentModel`.
    Does not reload the table view itself.

    - parameter model: The model to use for mapping to the content.
    */
    private func createCollectionData(model: ListCollectionModel.DataModel) {
        // Clear data.
        collectionData = [ListCollectionData]()

        // Save model.
        currentModel = model
       
        // Map model to table data.
        let mappedData = model.developers.map { (developer) -> ListCollectionData in
            let cellModel = ListDefaultCellModel(
            developer: developer
            )
            return ListCollectionData.defaultCell(cellModel)
        }
        collectionData += mappedData
        
        
    }
    func setData(model: ListCollectionModel.DataModel) {
        createCollectionData(model: model)
        ///DispatchQueue.main.async {
        self.collectionView.reloadData()
        self.collectionView.contentOffset = .zero
    }
}


extension ListCollectionController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       
        return collectionData.count
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: CGFloat(Const.List.mainViewBorder), left: 0, bottom: CGFloat(Const.List.mainViewBorder), right: 0)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return CGFloat(Const.List.mainViewBorder)
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let data = collectionData[indexPath.row]
        switch data {
        case let .defaultCell(cellModel):
            return defaultCell(model: cellModel, indexPath: indexPath)
        }
    }
        
    // MARK: - Cells

    private func defaultCell(model: ListDefaultCellModel, indexPath:IndexPath) ->ListDefaultCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Const.List.collectionCellID,for: indexPath) as? ListDefaultCell else {
            fatalError("No cell available")
        }
        cell.setup(model: model)
        return cell
    }
    
    private func showdefaultCell(model: ListDefaultCellModel, indexPath:IndexPath) -> Void {
       //  let image :UIImage
       // let developer = model.developer
         let data = collectionData[indexPath.row]
        switch data {
        case let .defaultCell(cellModel):
           let  cell = defaultCell(model: cellModel, indexPath: indexPath) as ListDefaultCell
        // image =  cell.getImage()
        }

        
       
       // logic.showTrailDetail(collectionView: collectionView, indexPath: indexPath, bottomDismiss: true,  trail:trail,image: image)
    
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cellWidth = 300
        return CGSize(width: cellWidth, height: 300)
    }
    
   
}
     
// MARK
// MARK: - Scene1DefaultCellDelegate

extension ListCollectionController: ListDefaultCellDelegate {
    func cellButtonPressed(cellModel: ListDefaultCellModel) {
       // logic.adoptSuggestion(cellModel.trail)
    }
}
