//
//  ListCollectionControllerInterface.swift
//  Trombinoscope
//
//  Created by lesly on 22.09.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import Foundation
import Shared
import UIKit

/// The interface to the collection.
protocol ListCollectionControllerInterface: AnyObject {
    /**
     Assigns the data model and reloads the table view.

     - parameter model: The data model.
     */
    func setData(model: ListCollectionModel.DataModel)
    
    
    func collectionViewScrollToTop()
}

/// The models send to the table controller.
struct ListCollectionModel {
    struct DataModel {
        /// The trails to present as table cells.
        let developers: GaleryResponse

    }
}

