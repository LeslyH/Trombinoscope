//
//  SearchListDefaultCell.swift
//  Suisse-rando-iOS
//
//  Created by lesly on 29.07.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//
import RxCocoa
import RxSwift
import Shared
import UIKit
import SDWebImage
import Anchorage


class ListDefaultCell: BaseCollectionCell {
    /// The cell's view to embed into the content view.
    private let cellView = ListDefaultCellView()

        
    override func configureView() {
        embedCellView(cellView)

  
       // cellView.trailTitleLabel.backgroundColor = SkeletonAppearance.default.tintColor
    }
    public func getImage() -> UIImage {
        return cellView.profileImageView.image!
        
    }
    // MARK: - Setup

    /// The cell's model.
    private var model: ListDefaultCellModel?

    /// The dispose bag for Rx.
    private var disposeBag = DisposeBag()

    /**
     Sets up the cell.

     - parameter model: The cell's model.
     */
    func setup(model: ListDefaultCellModel) {
        // Apply model.
        self.model = model
        // Reset previous bindings so they don't fire multiple times.
        disposeBag = DisposeBag()
        
        let developer :GaleryResponseElement = model.developer
              // set trail image
    
    
        cellView.descriptionLabel.text = developer.galeryResponseDescription
        cellView.nameLabel.text = developer.name
              
              
                    
                      
        let imageUrl = developer.picture
        if let imageFromCache = imageCache.object(forKey: imageUrl as NSString)
        {
            cellView.profileImageView.image = imageFromCache
        }else
        {
            cellView.profileImageView.sd_imageIndicator = SDWebImageActivityIndicator.medium
            cellView.profileImageView.sd_setImage(with: URL(string: imageUrl), placeholderImage: UIImage())

        }
        
        
        
    }

       
    
     //
     // MARK: - Touch Functions
     //
     
    // Make it appears very responsive to touch
     override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
         super.touchesBegan(touches, with: event)
       //  animate(isHighlighted: true)
     }

     override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
         super.touchesEnded(touches, with: event)
       //  animate(isHighlighted: false)
     }
     
     override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
         super.touchesCancelled(touches, with: event)
       //  animate(isHighlighted: false)
     }
}


