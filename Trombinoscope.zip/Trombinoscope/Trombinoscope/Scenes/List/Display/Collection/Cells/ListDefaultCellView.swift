//
//  SearchListDefaultCellView.swift
//  Suisse-rando-iOS
//
//  Created by lesly on 29.07.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import Anchorage
import Shared
import UIKit


class ListDefaultCellView: BaseView {
    override func configureView() {
        super.configureView()


        // Configure the cell
         add(profileImageView) { profileImageView in
            profileImageView.topAnchor == safeAreaLayoutGuide.topAnchor
            profileImageView.leadingAnchor == safeAreaLayoutGuide.leadingAnchor
            profileImageView.trailingAnchor == safeAreaLayoutGuide.trailingAnchor
            profileImageView.heightAnchor == 200
        }
        
         add(nameLabel) { nameLabel in
            nameLabel.topAnchor == profileImageView.bottomAnchor + 7
            nameLabel.leadingAnchor == safeAreaLayoutGuide.leadingAnchor + 7
            nameLabel.trailingAnchor == safeAreaLayoutGuide.trailingAnchor - 7
            nameLabel.heightAnchor == 16
           
        }
        
        add(descriptionLabel) { nameLdescriptionLabelabel in
            descriptionLabel.topAnchor == nameLabel.bottomAnchor + 7
            descriptionLabel.leadingAnchor == safeAreaLayoutGuide.leadingAnchor + 7
            descriptionLabel.trailingAnchor == safeAreaLayoutGuide.trailingAnchor - 7
            descriptionLabel.heightAnchor == 14
         }

        
       // trailBackgroundView.addSubview(trailImageViewActivityIndicator)
        configureImageView()

     
    }

    func configureImageView(){
           profileImageView.contentMode                                                                                       = .scaleAspectFill
           profileImageView.layer.masksToBounds                                                                               = true
           profileImageView.clipsToBounds    = true
                 
    }
    
    let nameLabel = UILabel()
    let descriptionLabel = UILabel()
    let profileImageView = UIImageView()

    // MARK: - Subviews



   
   // indicator on image downloading activity
 //  let  trailImageViewActivityIndicator = UIActivityIndicatorView(style: .large)
   //var imageViewCenterLayoutConstraint: NSLayoutConstraint!
    // MARK: - Interface Builder

    @IBInspectable private lazy var ibBackgroundColor: UIColor = .white
    @IBInspectable private lazy var ibTitle: String = "Title"

    override func prepareForInterfaceBuilder() {
        // For crash reports look at '~/Library/Logs/DiagnosticReports/'.
        super.prepareForInterfaceBuilder()
        backgroundColor = ibBackgroundColor
   
    }
}

