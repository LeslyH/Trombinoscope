//
//  SearchListDefaultCellModel.swift
//  Suisse-rando-iOS
//
//  Created by lesly on 29.07.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import Shared

/// The model for `SearchListDefaultCell`.
struct ListDefaultCellModel {
    /// The represented data.
    let developer: GaleryResponseElement

 
    /// The cell's delegate to inform about actions inside of the cell.
    weak var delegate: ListDefaultCellDelegate?
}

protocol ListDefaultCellDelegate: AnyObject {
    /**
     Informs that the cell button has been pressed.

     - parameter cellModel: The cell's model.
     */
    func cellButtonPressed(cellModel: ListDefaultCellModel)
}


