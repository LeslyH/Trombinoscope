import Anchorage
import Commons
import Shared
import UIKit

/**
 The scene's root view.
 The root view is responsible for creating the view hierarchy and holds all subview references.
 */
final class ListView: BaseView {
	override func configureView() {
		super.configureView()
		accessibilityIdentifier = Const.ListTests.mainView
        
        add(collectionView) { collectionView in
            collectionView.topAnchor == safeAreaLayoutGuide.topAnchor
            collectionView.leadingAnchor == safeAreaLayoutGuide.leadingAnchor
            collectionView.trailingAnchor == safeAreaLayoutGuide.trailingAnchor
            collectionView.bottomAnchor == safeAreaLayoutGuide.bottomAnchor
        }
        collectionView.backgroundColor = .yellow
        
	}
    /// The collectionView view covering most of the view.

    let collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        let cv = UICollectionView(frame: .zero,collectionViewLayout:layout)
        cv.backgroundColor = .systemGray6
        return cv
    }()
	// MARK: - Subviews

	// MARK: - Interface Builder

	@IBInspectable private lazy var ibBackgroundColor: UIColor = .white

	override func prepareForInterfaceBuilder() {
		// For crash reports look at '~/Library/Logs/DiagnosticReports/'.
		super.prepareForInterfaceBuilder()
		backgroundColor = ibBackgroundColor
	}
}
