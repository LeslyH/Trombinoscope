import UIKit
import ServerWorker
import Shared
/// The interface for presenting something in the view.
protocol ListPresenterInterface: AnyObject {
	/**
	 Updates the whole view according to the given state.

	 - parameter model: The new state.
	 */
	func updateView(model: ListModel.Presenter.UpdateView)
    
    
    /**
     Presents a server error via alert message to the user.

     - parameter error: The server error to present.
     */
    func serverError(_ error: ServerWorkerError)
    
    /**
    Updates the developers  list view with the given data.

    - parameter suggestions: The suggestions to display.
    */
    func developersList(developers: GaleryResponse )

}

extension ListModel {
	/// The models send to the presenter.
	enum Presenter {
		struct UpdateView {
		}
	}
}
