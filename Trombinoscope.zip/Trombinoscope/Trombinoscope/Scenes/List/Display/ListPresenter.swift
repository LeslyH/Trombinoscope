import UIKit
import ServerWorker
import Shared
/// Responsible for updating the view according to the data to present.
final class ListPresenter {
	/// A weak reference to the view controller for changing UIKit representation.
	/// Has to be assigned via property injection after initializing.
	weak var viewController: UIViewController?

	/// A weak reference to the view responsible for.
	/// Needs to be assigned by the view controller when the view gets created.
	weak var view: ListView?
    
    /// A weak reference to the collection controller.
     /// Needs to be assigned by the view controller when the view gets created.
    weak var collectionController: ListCollectionController?
}

// MARK: - ListPresenterInterface

extension ListPresenter: ListPresenterInterface {
	func updateView(model: ListModel.Presenter.UpdateView) {
	}
    
    func serverError(_ error: ServerWorkerError) {
         let alert = UIAlertController(title: "Error", message: "Error", preferredStyle: .alert)
         let defaultAction = UIAlertAction(title: "Error", style: .default, handler: nil)
         alert.addAction(defaultAction)
         viewController?.present(alert, animated: true, completion: nil)
     }
    
    func developersList(developers: GaleryResponse ){
        let collectionModel = ListCollectionModel.DataModel(developers: developers)

         collectionController?.setData(model: collectionModel)
        
    }
}
