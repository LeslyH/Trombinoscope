extension SetupModel {
	/// The scene's setup model.
	struct List {
		/// The closure for passing back some values to the previous scene.
		//let callback: ListCallback
	}

	typealias ListCallback = (_ model: ListResult) -> Void

	/// The model to pass back to the parent controller.
	struct ListResult {
	}
}
