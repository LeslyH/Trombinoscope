import Shared
let gold_number = ( 1 + (5).squareRoot()) / 2
extension Const {
	/// Any constants for this scene.
	struct List {
        
        /// The height of the search text field.
           static let searchFieldHeight = CGFloat(30)
           static let mainViewBorder = 10 * gold_number
           static let collectionCellID = "defaultCell"
           
           static let collectionCellHeight =  150 * gold_number//215.0 + 22//+ 70
           static let BackGroudColor :UIColor =  .systemGray
    }
    
   
    
}
