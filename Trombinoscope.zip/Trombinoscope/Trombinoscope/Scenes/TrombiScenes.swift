//
//  TrombiScenes.swift
//  Trombinoscope
//
//  Created by lesly on 22.09.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

enum TrombiScene {
    case list(SetupModel.List)
    case detail(SetupModel.Detail)
}

