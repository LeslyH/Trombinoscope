/// A namespace for scene set up models.
enum SetupModel {}
