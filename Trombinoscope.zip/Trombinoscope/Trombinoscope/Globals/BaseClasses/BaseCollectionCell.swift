//
//  BaseCollectionCell.swift
//  Suisse-rando-iOS
//
//  Created by lesly on 29.07.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import Anchorage
import UIKit

/**
 A base class for table view cells.
 Derive from this class instead of `UICollectionViewCell` directly.
 Override `configureView` to set up the view hierarchy and layout.
 */
class BaseCollectionCell: UICollectionViewCell {
        
    //
    // MARK: -   init functions
    //

    override init(frame: CGRect) {
        super.init(frame: frame)
        configureView()
    }

    @available(*, unavailable, message: "Instantiating via Xib & Storyboard is prohibited.")
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    /**
     Builds up the view hierarchy and applies the layout.
     Subclasses should override this method to set up the view's content and layout.
     The method `embedCellView()` might be used for that.
     The base implementation does nothing.
     */
    func configureView() {}

    /**
     Embeds a given cell view into the cell's content view.

     - parameter cellView: The cell's real view to show.
     */
    func embedCellView(_ cellView: UIView) {
        contentView.addSubview(cellView)
        cellView.edgeAnchors == contentView.edgeAnchors
    }
}
