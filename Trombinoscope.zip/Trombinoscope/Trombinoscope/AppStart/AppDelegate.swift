//
//  AppDelegate.swift
//  Trombinoscope
//
//  Created by lesly on 22.09.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

//
//  AppDelegate.swift
//  suisse-rando-iOS
//
//  Created by lesly on 27.07.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//
import SwiftMessages
import AppFolder
import ServerWorker
import Shared
import UIKit
import Reachability
import Anchorage
import UIKit



@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate ,UITabBarControllerDelegate {
    /// The reference to the window.
    var window: UIWindow?
    let noInternetMessageView = MessageView.viewFromNib(layout: .statusLine)
    let reachability = try! Reachability()

    var  backgroundTaskID: UIBackgroundTaskIdentifier?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        // Show indicator at top when internet not reachable
        // Show the scene.
        
        
        // Create window.
        let window = UIWindow(frame: UIScreen.main.bounds)
        self.window = window
        window.backgroundColor = .blue
        reachability.whenReachable = { reachability in
        SwiftMessages.hide()
        }
        reachability.whenUnreachable = { _ in
        Log.info("Internet not reachable")
            self.noInternetMessageView.backgroundView.backgroundColor = .systemRed
        self.noInternetMessageView.bodyLabel?.textColor = UIColor.white
        self.noInternetMessageView.configureContent(body: NSLocalizedString("No Internet Connection", comment: ""))

        var noInternetMessageViewConfig = SwiftMessages.defaultConfig
        noInternetMessageViewConfig.presentationContext = .window(windowLevel: UIWindow.Level(rawValue: 0))
        noInternetMessageViewConfig.preferredStatusBarStyle = .lightContent
        noInternetMessageViewConfig.duration = .forever

        SwiftMessages.show(config: noInternetMessageViewConfig, view: self.noInternetMessageView)
        }
        
        do {
        try reachability.startNotifier()
        } catch {
            Log.error("Unable to start reachability notifier")
        }

        // WORKAROUND: allows the widget to toggle VPN
        application.registerForRemoteNotifications()


        // Prepare initial act & scene.
                
                // Load config file.
        let config = ConfigLoader.parseFile()
        Log.debug("Config: \(config)\n\n------")
        ///Init sceen search
        let setupModel = SetupModel.List()
        let sceneType = TrombiScene.list(setupModel)
        let dependencies = TrombiDC(
            configuration: config,
            settings: InternalSettings(),
            serverWorker: ServerWorker(baseUrl: config.backendUrl)
        )
        let listScene = dependencies.factory.scene(sceneType)

            // Show the scene.
        window.rootViewController = listScene
        window.makeKeyAndVisible()
        return true
  
    }
        


  
    func application(_ application: UIApplication, willFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
     // LaunchScreenManager.instance.animateAfterLaunch(self.window!.rootViewController!.view)
        return true
    }
    
     
    func addblur(view: UIView){
        let blurEffect = UIBlurEffect(style: .systemThickMaterial)
        let blurView = UIVisualEffectView(effect: blurEffect)
        blurView.translatesAutoresizingMaskIntoConstraints = false
        view.insertSubview(blurView, at: 0)
        let vibrancyEffect = UIVibrancyEffect(blurEffect: blurEffect)
        let vibrancyView = UIVisualEffectView(effect: vibrancyEffect)
        vibrancyView.translatesAutoresizingMaskIntoConstraints = false
        blurView.contentView.addSubview(vibrancyView)
    }

      func applicationWillResignActive(_ application: UIApplication) {
         // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
         // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
     }

     func applicationDidEnterBackground(_ application: UIApplication) {
         // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
         // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
         //startOfflinePackDownload( )
     }

     func applicationWillEnterForeground(_ application: UIApplication) {
         // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
        do {
                    try reachability.startNotifier()
                } catch {
                    Log.error("Unable to start reachability notifier")
                }
               
     }

     func applicationDidBecomeActive(_ application: UIApplication) {
         // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        do {
                    try reachability.startNotifier()
                } catch {
                    Log.error("Unable to start reachability notifier")
                }
               
     }

     func applicationWillTerminate(_ application: UIApplication) {
         // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
     }






}
