public enum Const {
	// Specific constants will be defined in their extensions.
}
