import UIKit

extension Const {
	/// Globally app sepcific constants.
	public enum App {
		/// The app's group identifier.
		public static let groupIdentifier = "group.de.indie-software.demoapp"
	}
}
