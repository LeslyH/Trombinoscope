//
//  WayPoint.swift
//  swiss-rando-list
//
//  Created by lesly on 06.07.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import Foundation
import CoreLocation
public class WayPoint {
    typealias JSONDictionary = [String: Any]
    public let id :Int
    public let latitude: Double
    public let longitude: Double
    public let name: String
    public let order : Int
    public let trail_id: Int
    
    init(id:Int, latitude: Double, longitude: Double, name: String,order: Int, trail_id: Int) {
        self.id = id
        self.latitude = latitude
        self.longitude = longitude
        self.name = name
        self.order = order
        self.trail_id = trail_id
    }
    
    func getCoordinate2DMake() -> CLLocationCoordinate2D{
        
        return CLLocationCoordinate2DMake(self.latitude, self.longitude)
    }
    public static func fromJsonToObjectArray(array: [Any]) -> (String,[WayPoint]){
     var errorMessage = ""
        var wayPoints : [WayPoint] = []
        for trailDictionary in array {
                 var id = 0
                 var latitude = 0.0
                 var longitude = 0.0
                 var name = ""
                 var order = 0
                 var trail_id = 0
                
                 guard let trailDictionary = trailDictionary as? JSONDictionary else{
                    return (errorMessage,wayPoints)
                 }
                 
                 if let id_ = trailDictionary["id"] as? Int{ id = id_}else {errorMessage += ("waypoint/id trail Problem parsing trackDictionary\n")}
                 if let latitude_ = trailDictionary["latitude"] as? Double{ latitude = latitude_}else {errorMessage += ("waypoint/latitude trail Problem parsing trackDictionary\n")}
                 if let longitude_ = trailDictionary["longitude"] as? Double{ longitude = longitude_}else {errorMessage += ("waypoint/longitude trail Problem parsing trackDictionary\n")}
                 if let name_ = trailDictionary["name"] as? String{ name = name_}else {errorMessage += ("waypoint/name trail Problem parsing trackDictionary\n")}
                 if let order_ = trailDictionary["order"] as? Int{ order = order_}else {errorMessage += ("waypoint/order trail Problem parsing trackDictionary\n")}
                 if let trail_id_ = trailDictionary["trail_id"] as? Int{ trail_id = trail_id_}else {errorMessage += ("waypoint/trail_id trail Problem parsing trackDictionary\n")}
                 wayPoints.append(WayPoint(id:id, latitude: latitude, longitude: longitude, name: name,order: order, trail_id: trail_id))

        }
           return (errorMessage,wayPoints)
       }
}

