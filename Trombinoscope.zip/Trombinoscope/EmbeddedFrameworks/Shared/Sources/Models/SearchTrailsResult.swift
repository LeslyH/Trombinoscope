/// The result type of a `SearchAutocompletion.Query` request.
/// Should match something like `["Lorem",["lorem ipsum","lorem ipsum generator"]]` where the first "Lorem" is the query's string.
public struct SearchTrailsResult: Codable, Equatable {
    public static func == (lhs: SearchTrailsResult, rhs: SearchTrailsResult) -> Bool {
        return true
    }
    
//    public static func == (lhs: SearchTrailsResult, rhs: SearchTrailsResult) -> Bool {
//    
//    }
    

	/// The request's results representing the suggestions and maps to the second element
	/// in the array which is an array of strings.
	public var results: [Trail]
    public var scroll_id: String
    public var total: Int
    

	public init( results: [Trail], scroll_id: String,total: Int) {
		self.results = results
        self.scroll_id = scroll_id
        self.total = total
	}

	public init(from decoder: Decoder) throws {
		var container = try decoder.unkeyedContainer()
		results = try container.decode([Trail].self)
        scroll_id = try container.decode(String.self)
        total = try container.decode(Int.self)
	}

	public func encode(to encoder: Encoder) throws {
		var container = encoder.unkeyedContainer()
		try container.encode(results)
        try container.encode(scroll_id)
        try container.encode(total)
	}
}
