//
//  Coordinate3D.swift
//  MapSDKTEST
//
//  Created by lesly on 19.08.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import Foundation

public struct Coordinate3D: Comparable  {
    
    public let latitude : Double
    public let longitude : Double
    public let elevation : Double
    public init(latitude: Double, longitude: Double, elevation: Double) {
         
        self.latitude = latitude
        self.longitude = longitude
        self.elevation = elevation

       }

    public static func == (lhs: Coordinate3D, rhs: Coordinate3D) -> Bool {
        return lhs.elevation == rhs.elevation
    }

    public static func <(lhs: Coordinate3D, rhs: Coordinate3D) -> Bool {
        return lhs.elevation < rhs.elevation
    }
}
