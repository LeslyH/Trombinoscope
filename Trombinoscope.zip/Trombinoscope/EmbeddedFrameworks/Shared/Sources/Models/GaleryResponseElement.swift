//
//  GaleryResponseElement.swift
//  Trombinoscope
//
//  Created by lesly on 22.09.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//


import Foundation

// MARK: - GaleryResponseElement
public struct GaleryResponseElement: Codable {
   public  let id: Int
   public let name, galeryResponseDescription: String
   public  let picture: String
   public  let hired: Int

    enum CodingKeys: String, CodingKey {
        case id, name
        case galeryResponseDescription = "description"
        case picture, hired
    }
}

public typealias GaleryResponse = [GaleryResponseElement]
