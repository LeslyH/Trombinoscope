//
//  Geojson.swift
//  MapSDKTEST
//
//  Created by lesly on 23.08.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//


import Foundation

// MARK: - Welcome
public struct ResponseGeojson: Codable {
   public  let type: String
   public  let features: [Feature]
    public let name: String
}


// MARK: - Feature
public struct Feature: Codable {
   let type: FeatureType
  public   let properties: Properties
   public  let geometry: Geometry
}

// MARK: - Geometry
public struct Geometry: Codable {
   let type: GeometryType
  public   let coordinates: [Coordinate]
}

public enum Coordinate: Codable {
    case double(Double)
    case doubleArray([Double])

    public init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let x = try? container.decode([Double].self) {
            self = .doubleArray(x)
            return
        }
        if let x = try? container.decode(Double.self) {
            self = .double(x)
            return
        }
        throw DecodingError.typeMismatch(Coordinate.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for Coordinate"))
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .double(let x):
            try container.encode(x)
        case .doubleArray(let x):
            try container.encode(x)
        }
    }
}

enum GeometryType: String, Codable {
    case lineString = "LineString"
    case point = "Point"
}

// MARK: - Properties
public struct Properties: Codable {
    let index, snapped: String
    let subtype: String?
    let type: PropertiesType
    let stroke: String?
    let strokeOpacity, strokeWidth: Int?
    let profile: String?

  public   enum CodingKeys: String, CodingKey {
        case index, snapped, subtype, type, stroke
        case strokeOpacity = "stroke-opacity"
        case strokeWidth = "stroke-width"
        case profile
    }
}

enum PropertiesType: String, Codable {
    case controlPoint = "controlPoint"
    case segment = "segment"
}

enum FeatureType: String, Codable {
    case feature = "Feature"
}
