//
//  Trails.swift
//  Suisse-rando-iOS
//
//  Created by lesly on 28.07.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//
//
//import Foundation
//

public struct Trail  :Codable,Equatable {
  
  //
  // MARK: - Constants
  //
 // typealias JSONDictionary = [String: Any]
    public let id : Int // --
    public let name : String // ok
    public let description : String? // --
    public let description_full : String? // --
    public let time : String? // ok
    public let length : String? // ok
    public let ascent  : String // ok
    public let descent  : String // ok
    public let quotation  : String? // ok
    public let loop  : Bool? // ok
    public let departure  : String? // ok
    public let arrival  : String // ok
    public let info : String?  // ok
    public let season  : String?// ok
    public let effort : String // ok

}

public  struct ResponseTrail:Codable  {
    public var results: [Trail]
    public var scroll_id: String?
    public var total: Int
    
}

public typealias Trails = [Trail]
