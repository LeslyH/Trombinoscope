//
//  Nearest.swift
//  Shared
//
//  Created by lesly on 15.08.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import Foundation

// MARK: - Nearest
public struct Nearest: Codable {
    public let coordinates: [Double]
    public let distance: Double
    public let type: String
}

