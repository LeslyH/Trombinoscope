//
//  SearchTrails.swift
//  ServerWorker
//
//  Created by lesly on 30.07.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

//public struct SearchTrails:  Codable, Equatable {
//    public static func == (lhs: SearchTrails, rhs: SearchTrails) -> Bool {
//        false
//    }
//    
//
////    public static func == (lhs: SearchTrailsResult, rhs: SearchTrailsResult) -> Bool {
////
////    }
//    
//
//    /// The request's results representing the suggestions and maps to the second element
//    /// in the array which is an array of strings.
//    public var results: Trails
//    public var scroll_id: String
//    public var total: Int
//    
//
//    public init( results: Trails, scroll_id: String,total: Int) {
//        self.results = results
//        self.scroll_id = scroll_id
//        self.total = total
//    }
//
//    public init(from decoder: Decoder) throws {
//        var container = try decoder.unkeyedContainer()
//        results = try container.decode(Trails.self)
//        scroll_id = try container.decode(String.self)
//        total = try container.decode(Int.self)
//    }
//
//    public func encode(to encoder: Encoder) throws {
//        var container = encoder.unkeyedContainer()
//        try container.encode(results)
//        try container.encode(scroll_id)
//        try container.encode(total)
//    }
//}
