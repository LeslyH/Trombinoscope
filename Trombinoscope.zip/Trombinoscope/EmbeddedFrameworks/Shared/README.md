#  Shared

This framework is used by multiple targets of this project, e.g. the DemoApp main target and the DemoWidget.

Place any globally used types and constants here which are valid for multiple targets.
