#  Commons

This is a framework which contains special code suitable for other projects, too.
Consider extracting this framework into its own project and importing it as a non-embedded framework via CocoaPods or so. 

Any general utils and extensions find a place in this common framework.
