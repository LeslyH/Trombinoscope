#import <UIKit/UIKit.h>

//! Project version number for CustomViews.
FOUNDATION_EXPORT double CustomViewsVersionNumber;

//! Project version string for CustomViews.
FOUNDATION_EXPORT const unsigned char CustomViewsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CustomViews/PublicHeader.h>


