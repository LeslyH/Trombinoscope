#  CustomViews

A framework containing only custom views created for this project.

All globally used views placed in a framework makes it possible to import it in Playgrounds and use the views there.
