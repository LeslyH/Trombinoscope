//
//  SwiftMessages.h
//  SwiftMessages
//
//  Created by lesly on 29.08.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SwiftMessages.
FOUNDATION_EXPORT double SwiftMessagesVersionNumber;

//! Project version string for SwiftMessages.
FOUNDATION_EXPORT const unsigned char SwiftMessagesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftMessages/PublicHeader.h>


