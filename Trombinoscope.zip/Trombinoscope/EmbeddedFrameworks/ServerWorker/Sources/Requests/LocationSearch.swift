//
//  LocationSearch.swift
//  Shared
//
//  Created by lesly on 25.08.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//


import Shared

extension Request {
    /// Autocompletion suggestions for a search.
    public enum LocationSearch {
        
        /// Requests all suggestions for a given search query.
        /// Example query: https://api3.geo.admin.ch/rest/services/api/SearchServer?searchText=dent&type=locations
            public struct Query: ServerRequest {
            public typealias Response = LocationResponse
      
            public let resourceName = "SearchServer"

            public let httpMethod = HTTPMethod.GET
            enum CodingKeys: String, CodingKey {
                        case searchText = "searchText"
                        case type = "type"
                        case lang = "lang"
                    }

            /**
             Initializes the request with a query term.
             The query term must be not empty because the server doesn't support an empty query.

             - parameter query: The unmasked query term for which to get autocomplete suggestions.
             */
            public init(_ searchText:String) {
                precondition(!searchText.isEmpty, "start point query for drawing is not supported!")
                self.searchText = searchText
          
                
            }
            // MARK: - Parameter

            /// The query term to request autocompletion suggestions for.
       
                let type = "locations"
                let searchText :String
                let lang = "fr"
           
          
           
        }
    }
}


