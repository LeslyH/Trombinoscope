//
//  DrawRoute.swift
//  MapSDKTEST
//
//  Created by lesly on 11.08.20.
//  Copyright © 2020 Excellence-IT. All rights reserved.
//

import Shared

extension Request {
    /// Autocompletion suggestions for a search.
    public enum DrawRoute {
        
        /// Requests all suggestions for a given search query.
        /// Example query: https://graphhopper-neutral.schweizmobil.ch/route?vehicle=schmneutral&type=json&locale=fr-CH&weighting=fastest&elevation=true&way_point_max_distance=0&instructions=false&points_encoded=true&point=47.08665082188375,8.216811349579132&point=46.645167799648384,7.915344014323001
        public struct Query: ServerRequest {
            public typealias Response = ResponseRoute
      
            public let resourceName = "route"

            public let httpMethod = HTTPMethod.GET
            enum CodingKeys: String, CodingKey {
                        case startPoint = "startPoint"
                        case endPoint = "endPoint"
                         case vehicle = "vehicle"
                         case type = "type"
                         case locale = "locale"
                         case weighting = "weighting"
                         case elevation = "elevation"
                         case way_point_max_distance = "way_point_max_distance"
                         case instructions = "instructions"
                         case points_encoded = "points_encoded"
                    }

            /**
             Initializes the request with a query term.
             The query term must be not empty because the server doesn't support an empty query.

             - parameter query: The unmasked query term for which to get autocomplete suggestions.
             */
            public init(_ startPoint:String,endPoint:String) {
                precondition(!startPoint.isEmpty, "start point query for drawing is not supported!")
                precondition(!endPoint.isEmpty, "end point query for drawing is not supported!")
                self.startPoint = startPoint
                self.endPoint = endPoint
                
            }
            // MARK: - Parameter

            /// The query term to request autocompletion suggestions for.
                let vehicle = "schmneutral"
                let type = "json"
                let locale = "fr-CH"
                let weighting = "fastest"
                let elevation = "true"
                let startPoint :String
                let endPoint :String
                let way_point_max_distance = "0"
                let instructions = "false"
                let points_encoded = "false"
        }
    }
}

