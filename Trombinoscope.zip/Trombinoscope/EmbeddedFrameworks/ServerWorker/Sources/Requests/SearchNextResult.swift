import Shared

extension Request {
    /// Autocompletion suggestions for a search.
    public enum SearchNextResult {
        /// Requests all suggestions for a given search query.
        /// Example query: https://suggestqueries.google.com/complete/search?hl=en&output=firefox&q=ExampleQuery
        public struct SCROLL_ID: ServerRequest {
            public typealias Response = ResponseTrail

            public var resourceName = "scroll_trails/"

            public let httpMethod = HTTPMethod.GET
            enum CodingKeys: String, CodingKey {
                        case scroll_id = ""
                    
                    
                    }

            /**
             Initializes the request with a query term.
             The query term must be not empty because the server doesn't support an empty query.

             - parameter query: The unmasked query term for which to get autocomplete suggestions.
             */
            public init(_ scroll_id: String) {
                ///precondition(!query.isEmpty, "Empty query for autocompletion suggestions is not supported!")
                
                resourceName =  resourceName + scroll_id
            }
            // MARK: - Parameter

            /// The query term to request autocompletion suggestions for.
            let scroll_id: String = ""
     

 
        }
    }
}
