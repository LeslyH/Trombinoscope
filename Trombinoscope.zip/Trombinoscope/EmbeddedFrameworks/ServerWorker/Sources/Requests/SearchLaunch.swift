import Shared

extension Request {
	/// Autocompletion suggestions for a search.
	public enum SearchLaunch {
		/// Requests all suggestions for a given search query.
		/// Example query: https://suggestqueries.google.com/complete/search?hl=en&output=firefox&q=ExampleQuery
		public struct Query: ServerRequest {
			public typealias Response = ResponseTrail

			public let resourceName = "search_trails_all/"

			public let httpMethod = HTTPMethod.GET
            enum CodingKeys: String, CodingKey {
                        case query = ""
                    
                    
                    }

			/**
			 Initializes the request with a query term.
			 The query term must be not empty because the server doesn't support an empty query.

			 - parameter query: The unmasked query term for which to get autocomplete suggestions.
			 */
			public init(_ query: String) {
                ///precondition(!query.isEmpty, "Empty query for autocompletion suggestions is not supported!")
                self.query = ""
            }
            // MARK: - Parameter

            /// The query term to request autocompletion suggestions for.
            let query: String
     

 
		}
	}
}
