import Shared

extension Request {
    /// Autocompletion suggestions for a search.
    public enum SearchText {
        /// Requests all suggestions for a given search query.
        /// Example query: https://suggestqueries.google.com/complete/search?hl=en&output=firefox&q=ExampleQuery
        public struct Text: ServerRequest {
            public typealias Response = ResponseTrail

            public var resourceName = "search_trails/"

            public let httpMethod = HTTPMethod.GET
            enum CodingKeys: String, CodingKey {
                        case text = ""
                    
                    
                    }

            /**
             Initializes the request with a query term.
             The query term must be not empty because the server doesn't support an empty query.

             - parameter query: The unmasked query term for which to get autocomplete suggestions.
             */
            public init(_ text: String) {
                ///precondition(!query.isEmpty, "Empty query for autocompletion suggestions is not supported!")
                
                resourceName =  resourceName + text
            }
            // MARK: - Parameter

            /// The query term to request autocompletion suggestions for.
            let text: String = ""
     

 
        }
    }
}
