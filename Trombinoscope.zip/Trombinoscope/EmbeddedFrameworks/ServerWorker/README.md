#  ServerWorker

A worker framework with the responsibility to perform any server requests for this project.
